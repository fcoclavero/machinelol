import os
import jsonrequest as jr
import time
import sys
import logsystem as logsys


keys = {'c': "9b25bbda-7da3-4ee5-9d6b-a7ff2c402c0d", 'v': "0b808dbd-c044-43db-88a0-829dbd390aa7"}
# regions = ["br", "eune", "euw", "kr", "lan", "las", "na", "oce", "ru", "tr"]
regions = ["LA2"]
year = "2016"

# This script get UserIDs from a directory with the form: /<region>/<id>.json and requests the RankedStats to the API.

# Put here the directory that contains the region/ids.
sourceDir = "PlayerSummary"
key = keys['v']

if len(sys.argv) != 2:
    key = keys['v']
##
else:
    if sys.argv[1] == 'c':
        key = keys['c']
    else:
        key = keys['v']
print("Key selected: " + key)

for region in regions:
    if region == "LA2":
        foldername = "las"
    else:
        foldername = "lan"
	# First gets the player ids from the sourceDirectory.
    # Check if the region dir is contained in the source directory.
    regionPath = os.getcwd() + "/" + sourceDir + "/" + foldername
    # If not, then pass to the next region.
    if not os.path.exists(regionPath):
        print ("The region " + foldername + " doesn't exist in the directory.")
        continue

    try:
        logPath = "log_getPlayerMasteries" + region + ".txt"
        log = logsys.Log(logPath)

        # If the log was correctly loaded extract the content of the log.
        if log.loaded:
            loadedPlayerId = int(log.read())
            print("Loaded " + str(loadedPlayerId))

        else:
            loadedPlayerId = 1
        # Iterate over the files in the region source directory.
        for entry in os.listdir(regionPath):

            # Store the initial time
            t0 = time.time()
            # Split the filename of the form "<str>.<str>"
            (fileName, fileType) = entry.split('.')
                    # If the file is a json file is a valid one
            if fileType == "json":
                playerId = fileName

                # Checks if the saving directory exists and creates it if needed.
                outPath = os.getcwd() + "/" + "PlayerMasteries" + "/" + foldername + "/"
                if not os.path.exists(outPath):
                    print ("Creating folder: " + outPath)
                    os.makedirs(outPath)

                address = "https://" +  foldername + ".api.pvp.net/championmastery/location/" + region + "/player/" + str(playerId) + "/champions?api_key="

                outFile = outPath + str(playerId) + ".json"

                # Before making the request checks if the playerID was already requested.
                if os.path.exists(outFile) or str(playerId) < str(loadedPlayerId):
                    # If do exist, continue with the next playerId
                    continue


                print("Making request for ID: " + playerId)
                req = jr.Request(address, outFile, key)

                # If the request answer is: Internal server error, Service unavailable or Rate limit exceded
                timeout = 0
                while req.status in (429, 500, 503) or timeout > 100:
                    req = jr.Request(address, outFile, key)
                    timeout += 1

                # Any other response just pass to the next playerId (Successful or data not found)
                else:
                    pass

                # Synchronization module to prevent rate-limit exceeded response
                tf = time.time()
                dt = tf - t0
                if dt < 1200:
                    # hold until 1.2 secs; argument is in seconds, dt is in ms.
                    time.sleep(1.2 - dt / 1000)

                if timeout > 100:
                    print ("Timeout error")
                    break
                log.write(str(playerId))
    except Exception:
        print ("Error detected: " + type(Exception).__name__ + " in region " + region)
        print(" Saving ID in log: " + str(playerId))
        log.write(str(playerId))
    print("finished region " + region)

